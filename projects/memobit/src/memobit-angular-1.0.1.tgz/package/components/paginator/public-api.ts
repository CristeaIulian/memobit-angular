export * from './paginator.module';
