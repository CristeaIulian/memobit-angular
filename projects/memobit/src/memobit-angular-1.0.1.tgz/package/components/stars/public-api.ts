export * from './stars.module';
