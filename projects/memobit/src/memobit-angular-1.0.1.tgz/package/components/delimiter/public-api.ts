export * from './delimiter.module';
