import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  standalone: false,
  selector: 'mem-icon-technology-dot-net',

  changeDetection: ChangeDetectionStrategy.Eager,
  template: ` <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 256 256">
    <g fill="none">
      <rect width="256" height="256" fill="#512bd4" rx="60" />
      <path
        fill="#fff"
        d="M24.052 168.943c-2.236 0-4.138-.731-5.703-2.194c-1.566-1.501-2.349-3.283-2.349-5.347c0-2.101.783-3.902 2.349-5.403c1.565-1.5 3.467-2.251 5.703-2.251c2.274 0 4.194.751 5.76 2.251c1.603 1.501 2.404 3.302 2.404 5.403c0 2.064-.801 3.846-2.404 5.347c-1.566 1.463-3.486 2.194-5.76 2.194m89.415-1.238H98.929l-38.304-59.318a26.371 26.371 0 0 1-2.404-4.672h-.336c.298 1.726.447 5.422.447 11.087v52.903H45.471V87H60.96l37.018 57.912c1.566 2.402 2.572 4.052 3.02 4.953h.223c-.372-2.139-.559-5.759-.559-10.863V87h12.805zm62.631 0h-45.014V87h43.225v11.369h-29.916v22.849h27.568v11.312h-27.568v23.863h31.705zm63.973-69.336h-23.038v69.336h-13.309V98.369h-22.982V87h59.329z"
      />
    </g>
  </svg>`,
})
export class MemIconTechnologyDotNetComponent {}
