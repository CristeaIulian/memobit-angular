import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  standalone: false,
  selector: 'mem-icon-technology-xhr',

  changeDetection: ChangeDetectionStrategy.Eager,
  template: `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" stroke="#3c790a">
      <circle cx="50" cy="50" r="45" stroke-width="10" fill="#fff" />
      <path
        stroke-width="1.5"
        fill="none"
        d="M17,66C21,63,43,76,37,68M33,75a8,8,0,0,16,8M50,84C68,49,57,90,63,77,66,58,75,87,71,69,68,62,74,65,78,66M65,62C57,64,64,71,67,64M47,60L43,69,44,69,51,66M50,52C47,60,53,54,52,60,50,68,62,60,57,62,58,54,65,60,59,54,48,42,20,25,29,37M29,40C23,50,27,47,29,48M33,37C28,42,37,38,35,42,34,44,30,38,32,48,31,50,36,52,28,50M32,53L28,52M30,53C28,55,25,57,30,61,32,62,32,65,38,62,40,61,43,63,44,57,44,56,48,52,44,48L45,45,41,42,40,43,41,47,39,50,35,51M32,31C43,30,50,16,64,23M43,37C54,28,49,56,69,48,82,40,78,21,68,20L68,26C72,29,72,29,72,33"
      />
    </svg>
  `,
})
export class MemIconTechnologyXhrComponent {}
