import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  standalone: false,
  selector: 'mem-icon-technology-visual-basic',

  changeDetection: ChangeDetectionStrategy.Eager,
  template: ` <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 128 128">
    <path
      fill="#004e8c"
      d="M128 63.121a63.12 63.12 0 0 1-63.121 63.122A63.12 63.12 0 0 1 1.757 63.121A63.12 63.12 0 0 1 64.879 0A63.12 63.12 0 0 1 128 63.121"
    />
    <path fill="#fff" d="M21.127 17.753a63.121 63.121 0 1 0 89.12 89.12z" opacity="0.1" />
    <path
      fill="#fff"
      d="M61.17 38.168L47.125 77.619a21.7 21.7 0 0 0-1.104 4.498h-.138a23.4 23.4 0 0 0-1.006-4.398L31.068 38.268H24.58l18.03 49.709h6.488l18.326-49.71zm13.414.1v49.709h14.44a17.04 17.04 0 0 0 11.538-3.946a13 13 0 0 0 4.577-10.336a11.68 11.68 0 0 0-3.018-8.345a12.64 12.64 0 0 0-8.049-3.787v-.137a12.35 12.35 0 0 0 6.313-4.44a12.1 12.1 0 0 0 2.347-7.338a10.2 10.2 0 0 0-3.787-8.224a15.47 15.47 0 0 0-10.218-3.156zm12.525 5.187q9.528 0 9.528 7.24a8.03 8.03 0 0 1-2.742 6.508a11.32 11.32 0 0 1-7.477 2.367h-5.916V43.514zM80.502 64.8l6.607.02q11.993 0 11.993 8.796a8.3 8.3 0 0 1-2.82 6.649a11.84 11.84 0 0 1-7.891 2.425h-7.889z"
    />
  </svg>`,
})
export class MemIconTechnologyVisualBasicComponent {}
