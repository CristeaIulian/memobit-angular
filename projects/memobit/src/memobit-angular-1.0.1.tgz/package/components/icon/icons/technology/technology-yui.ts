import { Component } from '@angular/core';

@Component({
  standalone: false,
  selector: 'mem-icon-technology-yui',

  template: ` <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 512 512">
    <path
      fill="currentColor"
      d="M504.446 31.613A595.52 595.52 0 0 1 512 30.055C410.55 169.328 347.75 326 318.392 488.738c-62.672-6.601-115.079-24.339-169.417-54.58C194.917 296.265 334.294 125 504.445 31.613m-43.153 10.895C310.812 86.39 135.798 205.616 56.997 332.559c30.104 26.097 59.762 49.156 85.315 56.657C217.493 252.131 341.951 110.3 461.293 42.508m29.032-18.733C290.02 17.107 138.955 75.24 0 212.003c8.39 21.039 28.46 46.306 63.26 76.907C186.917 135.456 360.048 57.506 490.325 23.775"
    />
  </svg>`,
})
export class MemIconTechnologyYuiComponent {}
